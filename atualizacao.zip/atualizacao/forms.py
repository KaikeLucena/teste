from django import forms
from django.db import models
from .forms import Contato

class ContatoForm(forms.ModelForm):
      class Meta:
          model = Contato
          fields = ('nome', 'email', 'mensagem')
