import os
import os.path
import time
import shutil
import glob
import datetime
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow

navegador = webdriver.Chrome()

def login_pipefy():
 navegador.get("https://app.pipefy.com/pipes/302191264/reports_v2/300485267")

time.sleep(7)

campo_email = navegador.find_element(By.NAME, "username").send_keys("kaikelucena76@gmail.com")
time.sleep(2)

campo_email = navegador.find_element(By.NAME, "password").send_keys("44927539")
time.sleep(2) 

campo_email = navegador.find_element(By.NAME, "submit").click()
time.sleep(20)
    # Seu código para efetuar o login no Pipefy

def download_latest_report():
    # Seu código para baixar o relatório mais recente

campo_email = navegador.find_element("xpath", "//button[@aria-label='Exportar Relatório']").click()
time.sleep(20)

campo_email = navegador.find_element("xpath", "//*[@title='Download']").click()
time.sleep(20)

# Encontra o arquivo mais recente na pasta Downloads
download_path = os.path.join(os.path.expanduser("~"), "Downloads")
latest_file = max(glob.glob(download_path + "/*.xlsx"), key=os.path.getctime)

def move_report_to_folder():
    # Seu código para mover o relatório para a pasta Planilha Ritmo

def upload_report_to_drive():
    # Seu código para fazer o upload do relatório para o Google Drive

def main():
    # Inicia o navegador
    navegador = webdriver.Chrome()

    # Efetua o login no Pipefy
    login_pipefy()

    # Lista de URLs dos relatórios
    report_urls = [
        "URL_DO_RELATORIO_1",
        "URL_DO_RELATORIO_2",
        # Adicione as demais URLs dos relatórios aqui
    ]

    # Loop para processar cada relatório
    for url in report_urls:
        # Navega até a página do relatório
        navegador.get(url)

        # Espera um tempo para que a página carregue e os botões estejam disponíveis
        time.sleep(20)

        # Baixa o relatório
        download_latest_report()

        # Move o relatório para a pasta Planilha Ritmo
        move_report_to_folder()

        # Faz o upload do relatório para o Google Drive
        upload_report_to_drive()

    # Fecha o navegador após processar todos os relatórios
    navegador.quit()

if __name__ == "__main__":
    main()
