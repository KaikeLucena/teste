import os

def excluir_planilha(caminho_arquivo):
    try:
        # Verifica se o arquivo existe
        if os.path.exists(caminho_arquivo):
            # Exclui o arquivo
            os.remove(caminho_arquivo)
            print(f"O arquivo '{caminho_arquivo}' foi excluído com sucesso.")
        else:
            print(f"O arquivo '{caminho_arquivo}' não existe.")

    except OSError as error:
        print(f"Ocorreu um erro ao excluir o arquivo: {error}")

# Exemplo de uso
caminho_arquivo = 'C:\\Users\\Ritmo\Documents\\Codigos\Planilhas Ritmo\\3.xlsx'
excluir_planilha(caminho_arquivo)
